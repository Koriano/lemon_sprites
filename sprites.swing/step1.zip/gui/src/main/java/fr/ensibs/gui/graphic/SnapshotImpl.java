package fr.ensibs.gui.graphic;

import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of the {@link Snapshot} interface.
 *
 * @author Pascale Launay
 * @inv {@code getLayers() != null}
 */
public class SnapshotImpl implements Snapshot
{
    /**
     * the list of the snapshot layers
     */
    private final List<SnapshotLayer> layers;

    /**
     * Constructor. Initialize a snapshot with an empty list of layers
     */
    public SnapshotImpl()
    {
        this.layers = new ArrayList<>();
        this.invariant();
    }

    @Override
    public List<SnapshotLayer> getLayers()
    {
        return this.layers;
    }

    /**
     * Add a layer on top of the snapshot layers
     *
     * @param layer the new layer
     * @pre {@code layer != null}
     */
    public void addLayer(SnapshotLayer layer)
    {
        this.layers.add(layer);
        this.invariant();
    }

    //---------------------------------------------------------------
    // Private methods
    //---------------------------------------------------------------

    /**
     * Check the class invariant.
     */
    private void invariant()
    {
        assert getLayers() != null : "Invariant violated";
    }
}
