package fr.ensibs.gui.json;

import org.json.JSONObject;

import java.text.ParseException;
import java.util.Map;

import fr.ensibs.gui.graphic.Image;
import fr.ensibs.gui.graphic.SnapshotLayer;
import fr.ensibs.gui.graphic.SnapshotLayerImpl;

/**
 * Implementation of the {@link SnapshotLayerJsonConverter} interface.
 *
 * @author Pascale Launay
 */
public class SnapshotLayerJsonConverterImpl implements SnapshotLayerJsonConverter
{
    /**
     * the images used to make {@link SnapshotLayer} instances from JSON objects
     */
    private final Map<String, Image> images;

    /**
     * Constructor
     *
     * @param images the images used to make {@link SnapshotLayer} instances from JSON objects
     */
    public SnapshotLayerJsonConverterImpl(Map<String, Image> images)
    {
        this.images = images;
    }

    @Override
    public SnapshotLayer fromJson(JSONObject obj) throws ParseException
    {
        assert obj != null : "Precondition violated";

        SnapshotLayerImpl layer;
        if (obj.has("image")) {
            String imageName = obj.getString("image");
            Image image = images.get(imageName);
            if (image == null) {
                throw new ParseException("No image " + imageName, 0);
            }
            int width = !obj.has("width") ? image.getWidth() : obj.getInt("width");
            int height = !obj.has("height") ? image.getHeight() : obj.getInt("height");
            layer = new SnapshotLayerImpl(image, obj.getInt("x"), obj.getInt("y"), width, height);
        } else {
            layer = new SnapshotLayerImpl();
        }

        assert layer != null : "Postcondition violated";
        return layer;
    }

    @Override
    public JSONObject toJson(SnapshotLayer layer)
    {
        assert layer != null : "Precondition violated";

        JSONObject obj = new JSONObject();
        if (layer.getImage() != null) {
            obj.put("image", layer.getImage().getName());
            obj.put("x", layer.getX());
            obj.put("y", layer.getY());
            obj.put("width", layer.getWidth());
            obj.put("height", layer.getHeight());
        }

        assert obj != null : "Postcondition violated";
        return obj;
    }
}
