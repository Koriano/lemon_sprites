package fr.ensibs.gui.graphic;

/**
 * A layer composed of an image laying at a given location. The layer may be empty, i.e. have no
 * image.
 *
 * @author Pascale Launay
 */
public interface SnapshotLayer
{
    /**
     * Give the image drawn on the layer.
     *
     * @return the image drawn on the layer
     */
    Image getImage();

    /**
     * Give the x coordinate of the upper left bound of the image (in pixels).
     *
     * @return the x coordinate of the upper left bound of the image
     */
    int getX();

    /**
     * Give the y coordinate of the uper left bound of the image (in pixels).
     *
     * @return the y coordinate of the uper left bound of the image
     */
    int getY();

    /**
     * Give the width of the area used to display the image (in pixels).
     *
     * @return the width of the area used to display the image
     */
    int getWidth();

    /**
     * Give the height of the area used to display the image (in pixels).
     *
     * @return the height of the area used to display the image
     */
    int getHeight();
}
