package fr.ensibs.gui.json;

import org.json.JSONObject;

import java.text.ParseException;

import fr.ensibs.gui.graphic.SnapshotLayer;

/**
 * Class to convert {@link SnapshotLayer} instances to JSON objects and vice versa.
 *
 * @author Pascale Launay
 */
public interface SnapshotLayerJsonConverter
{
    /**
     * Give an instance of {@link SnapshotLayer} from a JSON object.
     *
     * @param obj a JSON object
     * @return an instance of {@link SnapshotLayer}
     * @throws ParseException if the given JSON object format doesn't match the {@link SnapshotLayer}
     *                        type
     * @pre {@code obj != null}
     * @post {@code result != null}
     */
    SnapshotLayer fromJson(JSONObject obj) throws ParseException;

    /**
     * Give a JSON object from a {@link SnapshotLayer} instance.
     *
     * @param layer an instance of {@link SnapshotLayer}
     * @return a JSON object
     * @pre {@code layer != null}
     * @post {@code result != null}
     */
    JSONObject toJson(SnapshotLayer layer);
}
