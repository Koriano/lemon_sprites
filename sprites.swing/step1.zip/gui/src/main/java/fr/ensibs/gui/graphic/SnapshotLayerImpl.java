package fr.ensibs.gui.graphic;

/**
 * Implementation of the {@link SnapshotLayer} interface.
 *
 * @author Pascale Launay
 */
public class SnapshotLayerImpl implements SnapshotLayer
{
    /**
     * the image drawn on the layer
     */
    private Image image;

    /**
     * the x coordinate of the upper left bound of the image
     */
    private int x;

    /**
     * the y coordinate of the upper left bound of the image
     */
    private int y;

    /**
     * the width of the area used to display the image
     */
    private int width;

    /**
     * the height of the area used to display the image
     */
    private int height;

    /**
     * Constructor. Initialize an empty layer (i.e. without image).
     */
    public SnapshotLayerImpl()
    {

    }

    /**
     * Constructor. Initialize a layer with an image and an area which size is the image size
     *
     * @param image the image drawn on the layer
     * @param x     the x coordinate of the upper left bound of the image
     * @param y     the x coordinate of the upper left bound of the image
     * @pre {@code image != null}
     */
    public SnapshotLayerImpl(Image image, int x, int y)
    {
        this(image, x, y, image.getWidth(), image.getHeight());
    }

    /**
     * Constructor. Initialize a layer with an image
     *
     * @param image  the image drawn on the layer
     * @param x      the x coordinate of the upper left bound of the image
     * @param y      the x coordinate of the upper left bound of the image
     * @param width  the width of the area used to display the image
     * @param height the height of the area used to display the image
     * @pre {@code image != null}
     * @pre {@code width >= 0 && height >= 0}
     */
    public SnapshotLayerImpl(Image image, int x, int y, int width, int height)
    {
        assert image != null : "Precondition violated";
        assert width >= 0 && height >= 0 : "Precondition violated";
        this.image = image;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    @Override
    public Image getImage()
    {
        return this.image;
    }

    @Override
    public int getX()
    {
        return this.x;
    }

    @Override
    public int getY()
    {
        return this.y;
    }

    @Override
    public int getWidth()
    {
        return this.width;
    }

    @Override
    public int getHeight()
    {
        return this.height;
    }
}
