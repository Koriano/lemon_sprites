/**
 * Package that provides classes or interfaces related to graphics for any graphic system.
 *
 * @author Pascale Launay
 */
package fr.ensibs.gui.graphic;
