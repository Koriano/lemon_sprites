package fr.ensibs.gui.graphic;

import java.util.List;

/**
 * A snapshot composed of different images in overlapped layers.
 *
 * @author Pascale Launay
 * @inv {@code getLayers() != null}
 */
public interface Snapshot
{
    /**
     * Give the layers that compose the snapshot
     *
     * @return the snapshot layers
     */
    List<SnapshotLayer> getLayers();
}
