package fr.ensibs.gui.graphic;

/**
 * A generic graphic system to draw snapshots.
 *
 * @author Pascale Launay
 * @inv {@code getWidth() >= 0 && getHeight() >= 0}
 */
public interface Graphic
{
    /**
     * Give the width of the graphic area in pixels.
     *
     * @return the width of the graphic area
     */
    int getWidth();

    /**
     * Give the height of the graphic area in pixels.
     *
     * @return the height of the graphic area
     */
    int getHeight();

    /**
     * Draw the given snapshot.
     *
     * @param snapshot the snapshot to be drawn
     * @pre {@code snapshot != null}
     */
    void draw(Snapshot snapshot);
}
