package fr.ensibs.gui.json;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.ParseException;
import java.util.Map;

import fr.ensibs.gui.graphic.Image;
import fr.ensibs.gui.graphic.Snapshot;
import fr.ensibs.gui.graphic.SnapshotImpl;
import fr.ensibs.gui.graphic.SnapshotLayer;

/**
 * Implementation of the {@link SnapshotJsonConverter} interface.
 *
 * @author Pascale Launay
 */
public class SnapshotJsonConverterImpl implements SnapshotJsonConverter
{
    /**
     * the converter used to convert {@link SnapshotLayer} from/
     */
    private final SnapshotLayerJsonConverter layerJsonConverter;

    /**
     * Constructor
     *
     * @param images the images used to make {@link Snapshot} instances from JSON objects
     */
    public SnapshotJsonConverterImpl(Map<String, Image> images)
    {
        this.layerJsonConverter = new SnapshotLayerJsonConverterImpl(images);
    }

    @Override
    public Snapshot fromJson(JSONObject obj) throws ParseException
    {
        assert obj != null : "Precondition violated";

        SnapshotImpl snapshot = new SnapshotImpl();
        if (obj.has("layers")) {
            JSONArray layers = obj.getJSONArray("layers");
            for (int i = 0; i < layers.length(); i++) {
                JSONObject layer = layers.getJSONObject(i);
                snapshot.addLayer(layerJsonConverter.fromJson(layer));
            }
        }

        assert snapshot != null : "Postcondition violated";
        return snapshot;
    }

    @Override
    public JSONObject toJson(Snapshot snapshot)
    {
        assert snapshot != null : "Precondition violated";

        JSONObject obj = new JSONObject();
        if (!snapshot.getLayers().isEmpty()) {
            JSONArray layers = new JSONArray();
            for (SnapshotLayer layer : snapshot.getLayers()) {
                layers.put(layerJsonConverter.toJson(layer));
            }
            obj.put("layers", layers);
        }

        assert obj != null : "Postcondition violated";
        return obj;
    }
}
