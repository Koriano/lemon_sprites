/**
 * Package that provides JSON utilities for the gui project classes and interfaces.
 *
 * @author Pascale Launay
 */
package fr.ensibs.gui.json;
