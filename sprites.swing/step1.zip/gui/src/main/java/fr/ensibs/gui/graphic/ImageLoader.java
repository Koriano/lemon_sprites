package fr.ensibs.gui.graphic;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;

/**
 * A factory to make images from input streams.
 *
 * @author Pascale Launay
 */
public interface ImageLoader
{
    /**
     * Make an {@link Image} instance by reading an input stream content.
     *
     * @param in the input stream
     * @return an image
     * @throws IOException    if the input stream cannot be accessed
     * @throws ParseException if the input stream doesn't contain a valid image
     * @pre {@code in != null}
     * @post {@code result != null && result.getWidth() >= 0 && result.getHeight() >= 0}
     */
    Image load(InputStream in) throws IOException, ParseException;
}
