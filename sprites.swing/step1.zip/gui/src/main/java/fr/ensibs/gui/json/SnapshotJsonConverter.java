package fr.ensibs.gui.json;

import org.json.JSONObject;

import java.text.ParseException;

import fr.ensibs.gui.graphic.Snapshot;

/**
 * Class to convert {@link Snapshot} instances to JSON objects and vice versa.
 *
 * @author Pascale Launay
 */
public interface SnapshotJsonConverter
{
    /**
     * Give an instance of {@link Snapshot} from a JSON object.
     *
     * @param obj a JSON object
     * @return an instance of {@link Snapshot}
     * @throws ParseException if the given JSON object format doesn't match the {@link Snapshot}
     *                        type
     * @pre {@code obj != null}
     * @post {@code result != null}
     */
    Snapshot fromJson(JSONObject obj) throws ParseException;

    /**
     * Give a JSON object from a {@link Snapshot} instance.
     *
     * @param snapshot an instance of {@link Snapshot}
     * @return a JSON object
     * @pre {@code snapshot != null}
     * @post {@code result != null}
     */
    JSONObject toJson(Snapshot snapshot);
}
