/**
 * Package that provides utility classes to manipulate JSON objects, developed using the org.json
 * API.
 *
 * @author Pascale Launay
 */
package fr.ensibs.util.json;
