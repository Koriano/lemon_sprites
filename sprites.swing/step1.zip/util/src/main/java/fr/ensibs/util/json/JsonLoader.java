package fr.ensibs.util.json;

import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.ParseException;

/**
 * Interface used to read/write JSON objects from JSON input/output streams.
 *
 * @author Pascale Launay
 */
public interface JsonLoader
{
    /**
     * Read a JSON object from a JSON input stream.
     *
     * @param in JSON input stream
     * @return a JSON object
     * @throws IOException    if an error occurs while reading from the input stream
     * @throws ParseException if an error occurs while making the object
     * @pre {@code in != null}
     * @post {@code result != null}
     */
    JSONObject load(InputStream in) throws IOException, ParseException;

    /**
     * Write an instance of a JSON object to a JSON output stream.
     *
     * @param out JSON output stream
     * @param obj a JSON object
     * @throws IOException if an error occurs while writing to the output stream
     * @pre {@code out != null && obj != null}
     */
    void save(JSONObject obj, OutputStream out) throws IOException;
}
