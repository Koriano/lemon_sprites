package fr.ensibs.util.json;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.ParseException;

/**
 * Implementation of the {@link JsonLoader} interface.
 *
 * @author Pascale Launay
 */
public class JsonLoaderImpl implements JsonLoader
{

    @Override
    public JSONObject load(InputStream in) throws IOException, ParseException
    {
        try {
            assert in != null : "Precondition violated";

            JSONTokener token = new JSONTokener(loadString(in));
            JSONObject obj = new JSONObject(token);

            assert obj != null : "Postcondition violated";
            return obj;
        } catch (JSONException e) {
            throw new ParseException("Error while parsing the JSON object. " + e.getClass().getName() + ":" + e.getMessage(), 0);
        }
    }

    @Override
    public void save(JSONObject obj, OutputStream out) throws IOException
    {
        assert out != null && obj != null : "Precondition violated";

        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out));
        writer.write(obj.toString(4) + "\n");
        writer.flush();
    }

    //--------------------------------------------------------------
    // Private methods
    //--------------------------------------------------------------

    /**
     * Load a string from a text input stream
     *
     * @param in an input stream
     * @return the string loaded from the input stream
     * @throws IOException if an error occurs while accessing the input stream
     * @pre {@code in != null}
     * @post {@code result != null}
     */
    private String loadString(InputStream in) throws IOException
    {
        assert in != null : "Precondition violated";

        StringBuilder builder = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        String line = reader.readLine();
        while (line != null) {
            builder.append(line).append("\n");
            line = reader.readLine();
        }
        String str = builder.toString();

        assert str != null : "Postcondition violated";
        return str;
    }
}
