package fr.ensibs.sprites;

import org.json.JSONObject;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import fr.ensibs.gui.graphic.Graphic;
import fr.ensibs.gui.graphic.Image;
import fr.ensibs.gui.graphic.ImageLoader;
import fr.ensibs.gui.graphic.Snapshot;
import fr.ensibs.gui.json.SnapshotJsonConverter;
import fr.ensibs.gui.json.SnapshotJsonConverterImpl;
import fr.ensibs.swing.graphic.SwingGraphic;
import fr.ensibs.swing.graphic.SwingImageLoader;
import fr.ensibs.util.json.JsonLoader;
import fr.ensibs.util.json.JsonLoaderImpl;

/**
 * The Swing frame composed of a panel with a main zone to display images. Entry point for the
 * Sprites application
 *
 * @author Pascale Launay
 */
public class SwingMain extends JFrame
{
    /**
     * the frame title
     */
    private static final String APP_TITLE = "Sprites";

    /**
     * the display area default width in pixels
     */
    private static final int WIDTH = 1024;

    /**
     * the display area default height in pixels
     */
    private static final int HEIGHT = 768;

    /**
     * the default JSON filename
     */
    private static final String JSON_FILE = "snapshot.json";

    /**
     * the default images filename
     */
    private static final String[] IMAGE_FILES = {"background-1.png", "palmtree-left.png", "palmtree-right.png", "tux.png"};

    /**
     * the application graphic context
     */
    private Graphic graphic;

    /**
     * Launch the Sprite application (entry point).
     *
     * @param args NONE
     */
    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                SwingMain frame = new SwingMain();
                frame.pack();
                frame.setVisible(true);

                frame.start();
            }
        });
    }

    /**
     * Constructor. Initialize the application's frame components.
     */
    public SwingMain()
    {
        super(APP_TITLE);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        makeComponents();
    }

    /**
     * Start the application.
     */
    public void start()
    {
        // load the images from the images files
        ImageLoader imageLoader = new SwingImageLoader();
        Map<String, Image> images = new HashMap<>();
        for (String imageName : IMAGE_FILES) {
            try (InputStream in = new FileInputStream(imageName)) {
                Image image = imageLoader.load(in);
                image.setName(imageName);
                images.put(imageName, image);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        // load the snapshot from the JSON file
        JsonLoader jsonLoader = new JsonLoaderImpl();
        SnapshotJsonConverter converter = new SnapshotJsonConverterImpl(images);
        try (InputStream in = new FileInputStream(JSON_FILE)) {
            JSONObject obj = jsonLoader.load(in);
            Snapshot snapshot = converter.fromJson(obj);
            // draw the snapshot
            graphic.draw(snapshot);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    //---------------------------------------------------------------
    // Private methods
    //---------------------------------------------------------------

    /**
     * Make the UI components composed of a single image panel
     */
    private void makeComponents()
    {
        JPanel imagePanel = new JPanel();
        imagePanel.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        this.graphic = new SwingGraphic(imagePanel);

        this.setLayout(new BorderLayout(5, 5));
        this.add(imagePanel, BorderLayout.CENTER);

    }
}
