/**
 * Package that contains classes representing the GUI for the Sprites application.
 *
 * @author Pascale Launay
 */
package fr.ensibs.sprites;
