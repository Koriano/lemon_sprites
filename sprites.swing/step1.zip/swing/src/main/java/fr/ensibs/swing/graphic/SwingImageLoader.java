package fr.ensibs.swing.graphic;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;

import javax.imageio.ImageIO;

import fr.ensibs.gui.graphic.Image;
import fr.ensibs.gui.graphic.ImageLoader;

/**
 * A factory to make images for the Java Swing graphic system.
 *
 * @author Pascale Launay
 */
public class SwingImageLoader implements ImageLoader
{
    @Override
    public Image load(InputStream in) throws IOException, ParseException
    {
        assert in != null : "Precondition violated";

        BufferedImage img = ImageIO.read(in);
        if (img == null || img.getWidth() < 0 || img.getHeight() < 0) {
            throw new ParseException("Invalid image format", 0);
        }
        Image image = new SwingImage(img);

        assert image != null : "Postcondition violated";
        assert image.getWidth() >= 0 && image.getHeight() >= 0 : "Postcondition violated";
        return image;
    }
}
