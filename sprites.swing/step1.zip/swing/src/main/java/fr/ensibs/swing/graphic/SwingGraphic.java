package fr.ensibs.swing.graphic;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JComponent;
import javax.swing.JPanel;

import fr.ensibs.gui.graphic.Graphic;
import fr.ensibs.gui.graphic.Snapshot;
import fr.ensibs.gui.graphic.SnapshotLayer;

/**
 * A graphic system to draw snapshots for Java Swing API.
 *
 * @author Pascale Launay
 * @inv {@code getWidth() >= 0 && getHeight() >= 0}
 */
public class SwingGraphic implements Graphic
{
    /**
     * the panel where images are drawn
     */
    private final ImagePanel panel;

    /**
     * the snapshot currently displayed (may be null)
     */
    private Snapshot currentSnapshot;

    /**
     * Constructor.
     *
     * @param component empty Swing component where images should be displayed
     * @pre {@code component != null}
     */
    public SwingGraphic(JComponent component)
    {
        assert component != null : "Precondition violated";

        this.panel = new ImagePanel(component);
        invariant();
    }

    @Override
    public int getWidth()
    {
        int width = this.panel.getWidth();
        if (width <= 0) {
            width = (int) Math.round(this.panel.getPreferredSize().getWidth());
        }
        if (width <= 0) {
            return 0;
        }
        return width;
    }

    @Override
    public int getHeight()
    {
        int height = this.panel.getHeight();
        if (height <= 0) {
            height = (int) Math.round(this.panel.getPreferredSize().getHeight());
        }
        if (height <= 0) {
            return 0;
        }
        return height;
    }

    @Override
    public void draw(Snapshot snapshot)
    {
        assert snapshot != null : "Precondition violated";

        this.currentSnapshot = snapshot;
        this.panel.repaint();
    }

    //---------------------------------------------------------------
    // Private methods
    //---------------------------------------------------------------

    /**
     * Check the class invariant.
     */
    private void invariant()
    {
        assert getWidth() >= 0 && getHeight() >= 0 : "Invariant violated";
    }


    //---------------------------------------------------------------
    // Inner class
    //---------------------------------------------------------------

    /**
     * Panel used to draw images
     */
    class ImagePanel extends JPanel
    {
        /**
         * Constructor
         *
         * @param component the component that will contain this panel
         * @pre {@code component != null}
         */
        public ImagePanel(JComponent component)
        {
            assert component != null : "Precondition violated";

            component.setLayout(new BorderLayout());
            component.add(this, BorderLayout.CENTER);
        }

        /**
         * Method called when the panel is repainted. Draw the current image if it exists
         *
         * @param graphics {@link Graphics} instance used to draw images
         * @pre {@code graphics != null}
         */
        @Override
        protected void paintComponent(Graphics graphics)
        {
            assert graphics != null : "Precondition violated";

            super.paintComponent(graphics);
            // draw the current snapshot if it exists
            if (currentSnapshot != null) {
                for (SnapshotLayer layer : currentSnapshot.getLayers()) {
                    BufferedImage image = ((SwingImage) layer.getImage()).getImage();
                    int x = layer.getX();
                    int y = layer.getY();
                    int width = layer.getWidth();
                    int height = layer.getHeight();
                    graphics.drawImage(image, x, y, width, height, null);
                }
            }
        }
    }
}
