package fr.ensibs.swing.graphic;

import java.awt.image.BufferedImage;

import fr.ensibs.gui.graphic.Image;

/**
 * An image for the Swing graphic system relying on a {@link BufferedImage} instance.
 *
 * @author Pascale Launay
 * @inv {@code getWidth() >= 0 && getHeight() >= 0}
 * @inv {@code getImage() != null}
 */
public class SwingImage implements Image
{
    /**
     * the image instance for the Java Swing graphic system
     */
    private final BufferedImage image;

    /**
     * the image name
     */
    private String name;

    /**
     * Initialize a Swing image.
     *
     * @param image {@link BufferedImage} instance
     * @pre {@code image != null}
     * @pre {@code image.getWidth() >= 0 && image.getHeight() >= 0}
     */
    public SwingImage(BufferedImage image)
    {
        assert image != null : "Precondition violated";
        assert image.getWidth() >= 0 && image.getHeight() >= 0 : "Precondition violated";

        this.image = image;
        invariant();
    }

    @Override
    public String getName()
    {
        return this.name;
    }

    @Override
    public void setName(String name)
    {
        this.name = name;
        invariant();
    }

    @Override
    public int getWidth()
    {
        return image.getWidth();
    }

    @Override
    public int getHeight()
    {
        return image.getHeight();
    }

    /**
     * Give the Swing image instance
     *
     * @return the Swing image
     * @post {@code result.getWidth() >= 0 && result.getHeight() >= 0}
     */
    public BufferedImage getImage()
    {
        BufferedImage image = this.image;
        assert image.getWidth() >= 0 && image.getHeight() >= 0 : "Postcondition violated";
        return image;
    }

    //---------------------------------------------------------------
    // Private methods
    //---------------------------------------------------------------

    /**
     * Check the class invariant.
     */
    private void invariant()
    {
        assert getImage() != null : "Invariant violated";
        assert getWidth() >= 0 && getHeight() >= 0 : "Invariant violated";
    }
}