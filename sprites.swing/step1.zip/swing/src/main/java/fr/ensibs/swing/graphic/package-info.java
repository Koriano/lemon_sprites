/**
 * Package that provides classes or interface related to graphism for a Java Swing graphic system.
 *
 * @author Pascale Launay
 */
package fr.ensibs.swing.graphic;
